<?php
  use Abraham\TwitterOAuth\TwitterOAuth;
  require "resource_files/vendor/autoload.php";

  class Twitter_Scraper {

    private $connection; // needed for later and management

    //intake nesscary information as well as search term
    function __construct($consumerKey, $consumerKeySecret, $accessToken, $accessTokenSecret) {
      //connect to Twitter API
      $this->connection = new TwitterOAuth($consumerKey, $consumerKeySecret, $accessToken, $accessTokenSecret);
    }
    //searchTwitter(string, int, string);
    function searchTwitter($searchTerm, $amt, $lang) {
      //construct request in proper format
      $query = array(
        "q" => $searchTerm,
        "count" => $amt,
        "lang" => $lang
      );

      return $this->connection->get('search/tweets', $query); // returns list of tweet objects
    }
    function sortAndStoreTweets($tweets, $file) {
      $fileWriter = fopen($file, "w"); // opens output file

      foreach($tweets->statuses as $tweet) { // loop through all text in each tweet
        fwrite($fileWriter, $tweet->text); // writes each line to file
      }

      fclose($fileWriter); // closes stream
    }
    //combines the two functions in one easy-to-call one
    function scrapeTwitter($searchTerm, $amt, $lang, $file) {
      $this->sortAndStoreTweets($this->searchTwitter($searchTerm, $amt, $lang), $file);
    }
  }
?>
