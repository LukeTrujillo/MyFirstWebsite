<?php
require 'resource_files/havenondemand-php/lib/hodclient.php';
include("resource_files/phpgraphlib/phpgraphlib_pie.php");

global $top_5_positive;
global $top_5_negative;

class Sentiment_Analysis {

  private $file; // location of data to send
  private $client; //object for interacting with HPE

  function __construct($API_KEY, $file) {
    $this->client = new HODCLient($API_KEY, $version = "v1");
    $this->file = $file;
  }

  function analyze() {
    $fileText = file_get_contents($this->file); // read text from file

    if($fileText == null) {
      echo 'no text';
    }

    $query  = array(
      'file' => 'scraped_data/tweetsFile.txt',
    'mode' => 'file'); //construct query

    $this->client->PostRequest($query, HODApps::ANALYZE_SENTIMENT, REQ_MODE::SYNC, 'responseGrabber');
  }
}
function responseGrabber($result) { //processes the data
  $array = (array) $result;

  $positive_arr = $array["positive"];
  $negative_arr = $array["negative"];

  $pos = 0;
  $neg = 0;

  $top_5_positive = array();
  $top_5_negative = array();

  foreach($positive_arr as $val) {
    $temp_arr = (array)$val;
    $pos += $temp_arr["score"];

    array_push($top_5_positive, $temp_arr["score"]);
  }
  foreach($negative_arr as $val) {
    $temp_arr = (array)$val;
    $neg += $temp_arr["score"];

    array_push($top_5_negative, -1 * $temp_arr["score"]);
  }
  $neg *= -1;

  rsort($top_5_positive);
  rsort($top_5_negative);

  $graph = new PHPGraphLibPie(400, 200, "interface/graph/graph.png");
  $data = array("Positive Responses" => $pos, "Negative Responses" => $neg);
  $graph->addData($data);
  $graph->setTitle("Search Results");
  $graph->setLabelTextColor('50,50,50');
  $graph->setLegendTextColor('50,50,50');
  $graph->createGraph();
}


?>
